# Android_Projects
A Git Library to with the Android Projects both Kotlin and Java
